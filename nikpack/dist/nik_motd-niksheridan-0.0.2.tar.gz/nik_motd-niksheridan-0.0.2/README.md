# Nik MOTD

This package is not intended for use, but rather as an exercise in 
packaging.